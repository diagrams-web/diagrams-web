# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['diagrams',
 'diagrams.alibabacloud',
 'diagrams.aws',
 'diagrams.azure',
 'diagrams.base',
 'diagrams.custom',
 'diagrams.digitalocean',
 'diagrams.elastic',
 'diagrams.firebase',
 'diagrams.gcp',
 'diagrams.generic',
 'diagrams.ibm',
 'diagrams.k8s',
 'diagrams.oci',
 'diagrams.onprem',
 'diagrams.openstack',
 'diagrams.outscale',
 'diagrams.programming',
 'diagrams.saas']

package_data = \
{'': ['*']}

install_requires = \
['graphviz>=0.13.2,<0.20.0', 'jinja2>=2.10,<4.0']

extras_require = \
{':python_version >= "3.6" and python_version < "3.7"': ['contextvars>=2.4,<3.0']}

entry_points = \
{'console_scripts': ['diagrams = diagrams.cli:main']}

setup_kwargs = {
    'name': 'diagrams',
    'version': '0.21.1.1',
    'description': 'Extended version of diagrams',
    'long_description': '# diagrams-xtd\nExtended version of diagrams with some PR that never get merged and I want to use.\n\nMore details in [CHANGELOG](CHANGELOG.md). \n',
    'author': 'Diagrams-web',
    'author_email': 'no_spam@nowhere.mail',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/gabriel-tessier/diagrams-xtd',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
