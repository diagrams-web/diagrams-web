# diagrams-xtd
Extended version of diagrams with some PR that never get merged and I want to use.

More details in [CHANGELOG](CHANGELOG.md). 
